import './App.css';


import CountNum from './counter';

export function App() {
  return (
    <div className="App">
    <CountNum/>
    </div>
  );
}

export default App;
